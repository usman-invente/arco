<?php


return [

    'title'=>'Organization Section',
    'title_description'=>'Organizations Management',
    'add_button'=>'Add organization',

    'data_table_title_1'=>'Assembly Name (English)',
    'data_table_title_0'=>'Assembly Name (Arabic)',
    'data_table_title_2'=>'SuperVisor',
    'data_table_title_3'=>'Email',
    'data_table_title_4'=>'Contact Number With Country Code',
    'data_table_title_5'=>'Status',
    'data_table_title_6'=>'Action',
    'data_table_title_7'=>'Logo Image',
    'data_table_title_8'=>'banner Image',
    'data_table_title_9'=>'Password',
    'data_table_title_10'=>'Contact By',

    'image_not_exist'=>'Image Not Exist upload please.'
];

