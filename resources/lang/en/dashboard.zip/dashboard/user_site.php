<?php

return [

    'title'=>'User Section',
    'title_description'=>'User Registration',

    'data_table_title_1'=>'Full Name',
    'data_table_title_2'=>'E-Mail Address',
    'data_table_title_3'=>'Nationality',
    'data_table_title_4'=>'Contact Number',
    'data_table_title_5'=>'Qualification',
    'data_table_title_6'=>'Address',
    'data_table_title_7'=>'City',
    'data_table_title_8'=>'Volunteering Field',

];
