<?php




return [

    'title'=>'Permission Section',
    'title_description'=>'Permission Management ',
    'add_button'=>'Add Permission',

    'data_table_title_1'=>'Id',
    'data_table_title_2'=>'Permission',
    'data_table_title_3'=>'created_at',
    'data_table_title_4'=>'Action',
];
