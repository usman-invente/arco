<?php


return [

   'title'=>'Admin Account',
   'title_description'=>'Admin Information Edit | Check',

    'tab_1'=>'Personal Info',
    'tab_2'=>'Update Info',
    'tab_3'=>'Change Password',

    'data_title_1'=>'Current Password',
    'data_title_2'=>'New Password',
    'data_title_3'=>'Confirm Password',
];
