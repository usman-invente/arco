<?php

return [

    'title'=>'Website Footer Section',
    'title_description'=>'Footer of the Websites',

    'data_table_title_1'=>'Description In footer',
    'data_table_title_2'=>'Facebook Link',
    'data_table_title_3'=>'Twitter Link',
    'data_table_title_4'=>'Instagram Link',
    'data_table_title_5'=>'YouTube Link',
];
