<?php

return [

    'title'=>'Website Counter Section',
    'title_description'=>'Counters of the Websites',

    'data_table_title_1'=>'Number Of Volunteer',
    'data_table_title_2'=>'Number Of Volunteer Opportunities',
    'data_table_title_3'=>'Number Of Volunteer Hours',
    'data_table_title_4'=>'Number Of Organizations',
    'data_table_title_5'=>'Data Select From',
];
