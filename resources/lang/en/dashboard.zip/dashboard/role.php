<?php

        return [

            'title'=>'Roles Section',
            'title_description'=>'Roles Management (You can Not Delete or change the Roles Name of the System)',
            'add_button'=>'Add Roles',

            'data_table_title_1'=>'Id',
            'data_table_title_2'=>'Role',
            'data_table_title_3'=>'Permissions',
            'data_table_title_4'=>'Action',
        ];
