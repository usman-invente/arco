<?php

return [

    'title'=>'News Section',
    'title_description'=>'News Management',

    'data_table_title_1'=>'Description',
    'data_table_title_2'=>'Address',
    'data_table_title_3'=>'Status',
    'data_table_title_4'=>'Updated By',
    'data_table_title_5'=>'Created AT',
    'data_table_title_6'=>'Action',
    'data_table_title_7'=>'Content',
    'data_table_title_8'=>'Image',
    'data_table_title_9'=>'Created By',
    'image_not_exist'=>'Image Not Exist upload please.'
];
