<?php

return [

    'title'=>'Call Us Section',
    'title_description'=>'Contact Us information on the Website',




    'data_table_title_1'=>'Main Address',
    'data_table_title_2'=>'Second Address',
    'data_table_title_3'=>'Main Phone',
    'data_table_title_4'=>'Second Phone',
    'data_table_title_5'=>'Email Address',
    'data_table_title_6'=>'Second Email Address',
    'data_table_title_7'=>'Location',
    'data_table_title_8'=>'time'
];
