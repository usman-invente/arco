<?php

return [

    'title'=>'Managing Pages',
    'title_description'=>'Pages Management',

    'data_table_title_1'=>'Title',
    'data_table_title_2'=>'Status',
    'data_table_title_3'=>'updated BY',
    'data_table_title_4'=>'Updated AT',
    'data_table_title_5'=>'Action',
    'data_table_title_6'=>'Created AT',
    'data_table_title_7'=>'content',

];
