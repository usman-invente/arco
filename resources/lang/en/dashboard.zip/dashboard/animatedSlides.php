<?php

return [

    'title'=>'Animated Slides Section',
    'title_description'=>'Banners for the Websites',

    'add_button'=> 'Add Slide',
    'data_table_title_1'=>'Name',
    'data_table_title_2'=>'Picture',
    'data_table_title_3'=>'Status',
    'data_table_title_4'=>'Sequence',
    'data_table_title_5'=>'Created AT',
    'data_table_title_6'=>'Action',
    'data_table_title_7'=>'Content',
    'data_table_title_9'=>'Image',
];
