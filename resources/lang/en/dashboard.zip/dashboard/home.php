<?php


return [

    'title'=>'Dashboard',
    'tile_1'=>'Number Of Volunteers',
    'tile_2'=>'Number Of Volunteer Opportunities',
    'tile_3'=>'Number Of Volunteer Hours',
    'tile_4'=>'Number Of organizations',
    'stat'=>'Stat',

    'head_logo' => 'Website Header Logo',
    'footer_logo'=>'Website Footer Logo',
    'logo_section_title'=>' LOGO Section ',
    'logo_title_description'=>'Change or update the Logos of the Web',
];
