<?php



return [

    'site_administration'=>'Site Administration',
    'pages_Manager'=>'Pages Manager',
    'dashboard'=>'Dashboard',
    'administration'=>'Administration',

];
